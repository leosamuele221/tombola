import tombola.Cartella.*;

class main {
    public static void main(String[] args) {
        Cartella cartella1 = new Cartella();
        cartella1.setVisible(true);
    }
}