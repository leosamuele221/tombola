import tombola.Tabellone.*;

class main {
    public static void main(String[] args) {
        Tabellone tabellone = new Tabellone();
        tabellone.setVisible(true);
    }
}